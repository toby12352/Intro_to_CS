Name : Tun Aung Thaung
ONID : thaungt
Section : CS_162_001_U2020
Assignment 2, due 7/19/2020

Description

This program provide a game called Go Fish. In this game, the player's use player cards to play against each other. You have to try to collect four
cards of same rank in order to create one book. The game ends when there is no card in deck and in player's hand. The winner is deicded on who have
the most books at the end of the game.
Player can ask for a same rank of a card that he owns from the opponent, if the opponent has the same rank, he has to give all the cards and if the
opponent does not have it, the player needs to draw a card from deck and if the drew card is the card that he asks from the opponent, his turn can
keep going unless he doesn't receieve the card that he requested.

Instructions : 

1) To compile the program : Easily type make and the makefile which includes all the program files will compile.
2) To run the program : type "./go_fish" in the command line
   When running program. The user needs to type exact words as above or the loading file will fail and the user won't be able to start the program.
3) Once you started the program, the cards in the deck will shuffle and will be dealt to both you and the computer's hand.
4) After that the program will ask for you to choose a card to request from your opponent.

Limitation :

~